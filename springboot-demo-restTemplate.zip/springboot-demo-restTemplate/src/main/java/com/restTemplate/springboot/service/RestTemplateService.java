package com.restTemplate.springboot.service;

import java.net.URL;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import com.restTemplate.springboot.dto.PrimeTrustDto;
import org.slf4j.Logger;

@Service
public class RestTemplateService {

	private static final Logger Log = LoggerFactory.getLogger(RestTemplateService.class);

	@Autowired
	private RestTemplate restTemplate;

	public ResponseEntity<String> postWebService(PrimeTrustDto dto) {
		HttpHeaders header = new HttpHeaders();
		header.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		header.put("Content-Type", Arrays.asList("application/json"));
		header.setBearerAuth(
				"eyJhbGciOiJSUzI1NiJ9.eyJhdXRoX3NlY3JldCI6Ijc0N2Y2NTM2LTI2YWEtNDVlNi1iNjNjLTNkM2UxZTQ4ZjRkNyIsInVzZXJfZ3JvdXBzIjpbXSwibm93IjoxNjY5OTYzNzY5LCJleHAiOjE2NzUxMjMyMDB9.UIcy0NVSM14KFhtDPQx9lURRArqCMeTuDTn3ckI09zxgoCrNKxOpUp0jG8HIA5rKk5jwaTnICIXrphcUO0xu4aIK5uJSblTKCH6qBnWkB2Dz5XldeAZLH2AfP6-ZnBUz6J03z-W2s-_RTVQprMY-0_wWlHKvn_EkUGpHKTDWvwjAg7luebokPj9sarUz2N20X7BPHbejEcbyiO5GeC1fYL1TZLm5m9E--vEfLtOkAQPbloz5lKhdW1WaMl7Rmq5hDsJ-vnfkYNbrfH77FO02cHgzxkHnOkH1-gk_a8DMsIAmBYt9bYDBqdMBqrO_JwEapPMZcZYyxxgoUibcp7P1Kg");
		String jsonArray = "{\r\n" + "    \"data\": {\r\n" + "        \"type\": \"account\",\r\n"
				+ "        \"attributes\": {\r\n" + "            \"account-type\": \"custodial\",\r\n"
				+ "             \"name\":\"" + dto.getName() + "\",\r\n" + "            \"authorized-signature\": \""
				+ dto.getAuthorizedSignature() + "\",\r\n" + "            \"webhook-config\": {\r\n"
				+ "                \"url\": \"https://webhook.site/74212417-6430-42ec-83ed-554b94e82d76\"\r\n"
				+ "            },\r\n" + "            \"owner\": {\r\n"
				+ "                \"contact-type\": \"natural_person\",\r\n" + "                \"name\": \""
				+ dto.getOwnerName() + "\",\r\n" + "                \"email\": \"" + dto.getEmail() + "\",\r\n"
				+ "                \"date-of-birth\": \"" + dto.getDateOfBirth() + "\",\r\n"
				+ "                \"tax-id-number\": \"" + dto.getTaxIdNumber() + "\",\r\n"
				+ "                \"tax-country\": \"" + dto.getTaxCuntry() + "\",\r\n"
				+ "                \"ip-address\": \"" + dto.getIpAddress() + "\",\r\n"
				+ "                \"geolocation\": \"" + dto.getGeoLocation() + "\",\r\n"
				+ "                \"primary-phone-number\": {\r\n" + "                    \"country\": \""
				+ dto.getCountry() + "\",\r\n" + "                    \"number\": \"" + dto.getNumber() + "\",\r\n"
				+ "                    \"sms\": " + dto.isSms() + "\r\n" + "                },\r\n"
				+ "                \"primary-address\": {\r\n" + "                    \"street-1\": \""
				+ dto.getStreetOne() + "\",\r\n" + "                    \"street-2\": \"" + dto.getStreetTwo()
				+ "\",\r\n" + "                    \"postal-code\": \"" + dto.getPostalCode() + "\",\r\n"
				+ "                    \"city\": \"" + dto.getCity() + "\",\r\n" + "                    \"region\": \""
				+ dto.getRegion() + "\",\r\n" + "                    \"country\": \"" + dto.getPaCountry() + "\"\r\n"
				+ "                }\r\n" + "            }\r\n" + "        }\r\n" + "    }\r\n" + "}";
		Log.info("Json {}", jsonArray);
		HttpEntity<String> entity = new HttpEntity<>(jsonArray, header);
		ResponseEntity<String> response = restTemplate.exchange(
				"https://sandbox.primetrust.com/v2/accounts?include=contacts", HttpMethod.POST, entity, String.class);
		Log.info("response {}", response);

		return response;

	}

	public String getDetails(String id) {
		HttpHeaders header = new HttpHeaders();
		header.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		String url = "https://sandbox.primetrust.com/v2/webhook-configs?account.id=" + id;
		header.setBearerAuth(
				"eyJhbGciOiJSUzI1NiJ9.eyJhdXRoX3NlY3JldCI6Ijc0N2Y2NTM2LTI2YWEtNDVlNi1iNjNjLTNkM2UxZTQ4ZjRkNyIsInVzZXJfZ3JvdXBzIjpbXSwibm93IjoxNjY5OTYzNzY5LCJleHAiOjE2NzUxMjMyMDB9.UIcy0NVSM14KFhtDPQx9lURRArqCMeTuDTn3ckI09zxgoCrNKxOpUp0jG8HIA5rKk5jwaTnICIXrphcUO0xu4aIK5uJSblTKCH6qBnWkB2Dz5XldeAZLH2AfP6-ZnBUz6J03z-W2s-_RTVQprMY-0_wWlHKvn_EkUGpHKTDWvwjAg7luebokPj9sarUz2N20X7BPHbejEcbyiO5GeC1fYL1TZLm5m9E--vEfLtOkAQPbloz5lKhdW1WaMl7Rmq5hDsJ-vnfkYNbrfH77FO02cHgzxkHnOkH1-gk_a8DMsIAmBYt9bYDBqdMBqrO_JwEapPMZcZYyxxgoUibcp7P1Kg");

		HttpEntity<String> entity = new HttpEntity<>(header);

		ResponseEntity<String> res = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		Log.info("response {}", res);
		String contactemail = null;
		JSONObject object = new JSONObject(res.getBody());
		Log.info("object{}", object);
		JSONArray jsonArray = object.getJSONArray("data");
		Log.info("JSONArray {}" + jsonArray);
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i).getJSONObject("attributes");
			contactemail = jsonObject.get("contact-email").toString();
		}

		return contactemail;
	}

	public Map<String, Object> getDetail(String id) {
		Map<String, Object> response = new HashMap<>();
		HttpHeaders header = new HttpHeaders();
		header.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		String url = "https://sandbox.primetrust.com/v2/webhook-configs?account.id=" + id;
		header.setBearerAuth(
				"eyJhbGciOiJSUzI1NiJ9.eyJhdXRoX3NlY3JldCI6Ijc0N2Y2NTM2LTI2YWEtNDVlNi1iNjNjLTNkM2UxZTQ4ZjRkNyIsInVzZXJfZ3JvdXBzIjpbXSwibm93IjoxNjY5OTYzNzY5LCJleHAiOjE2NzUxMjMyMDB9.UIcy0NVSM14KFhtDPQx9lURRArqCMeTuDTn3ckI09zxgoCrNKxOpUp0jG8HIA5rKk5jwaTnICIXrphcUO0xu4aIK5uJSblTKCH6qBnWkB2Dz5XldeAZLH2AfP6-ZnBUz6J03z-W2s-_RTVQprMY-0_wWlHKvn_EkUGpHKTDWvwjAg7luebokPj9sarUz2N20X7BPHbejEcbyiO5GeC1fYL1TZLm5m9E--vEfLtOkAQPbloz5lKhdW1WaMl7Rmq5hDsJ-vnfkYNbrfH77FO02cHgzxkHnOkH1-gk_a8DMsIAmBYt9bYDBqdMBqrO_JwEapPMZcZYyxxgoUibcp7P1Kg");
		Log.info("header {}", header);
		HttpEntity<String> entity = new HttpEntity<>(header);

		ResponseEntity<String> res = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		Log.info("response {}", res);
		// String related = null;
		JSONObject object = new JSONObject(res.getBody());
		JSONArray jsonArray = object.getJSONArray("data");
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject relationships = jsonArray.getJSONObject(i).getJSONObject("relationships");
			JSONObject account = relationships.getJSONObject("account");
			JSONObject links = account.getJSONObject("links");
			response.put("related", links.get("related").toString());
		}
		return response;
	}

//	public ResponseEntity<String> postDocument(MultipartFile file, MultipartFile file1) {
//		HttpHeaders header = new HttpHeaders();
//		header.setAccept(Arrays.asList(MediaType.MULTIPART_FORM_DATA));
//		header.setBearerAuth(
//				"eyJhbGciOiJSUzI1NiJ9.eyJhdXRoX3NlY3JldCI6Ijc0N2Y2NTM2LTI2YWEtNDVlNi1iNjNjLTNkM2UxZTQ4ZjRkNyIsInVzZXJfZ3JvdXBzIjpbXSwibm93IjoxNjY5OTYzNzY5LCJleHAiOjE2NzUxMjMyMDB9.UIcy0NVSM14KFhtDPQx9lURRArqCMeTuDTn3ckI09zxgoCrNKxOpUp0jG8HIA5rKk5jwaTnICIXrphcUO0xu4aIK5uJSblTKCH6qBnWkB2Dz5XldeAZLH2AfP6-ZnBUz6J03z-W2s-_RTVQprMY-0_wWlHKvn_EkUGpHKTDWvwjAg7luebokPj9sarUz2N20X7BPHbejEcbyiO5GeC1fYL1TZLm5m9E--vEfLtOkAQPbloz5lKhdW1WaMl7Rmq5hDsJ-vnfkYNbrfH77FO02cHgzxkHnOkH1-gk_a8DMsIAmBYt9bYDBqdMBqrO_JwEapPMZcZYyxxgoUibcp7P1Kg");
//		MultiValueMap<String, Object> body=new LinkedMultiValueMap<>();
//		body.add("file", file);
//		body.add("file11", file);
//		HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, header);
//		String url="https://sandbox.primetrust.com/v2/uploaded-documents";
//		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
//		return response;
//	}

	public ResponseEntity<String> postDocument(MultipartFile file,String id) {
		ResponseEntity<String> response = null;
		try {
			String fileName = file.getOriginalFilename();
			byte[] fileContent = file.getBytes();
			//byte[] fileContent = file.getOriginalFilename().getBytes();
			HttpHeaders parts = new HttpHeaders();
			parts.setContentType(MediaType.IMAGE_PNG);
			final ByteArrayResource byteArrayResource = new ByteArrayResource(fileContent) {

				@Override
				public String getFilename() {
					return fileName;
				}
			};
			final HttpEntity<ByteArrayResource> partsEntity = new HttpEntity<>(byteArrayResource, parts);
			HttpHeaders header = new HttpHeaders();
			header.setAccept(Arrays.asList(MediaType.MULTIPART_FORM_DATA));
			header.setBearerAuth(
					"eyJhbGciOiJSUzI1NiJ9.eyJhdXRoX3NlY3JldCI6Ijc0N2Y2NTM2LTI2YWEtNDVlNi1iNjNjLTNkM2UxZTQ4ZjRkNyIsInVzZXJfZ3JvdXBzIjpbXSwibm93IjoxNjY5OTYzNzY5LCJleHAiOjE2NzUxMjMyMDB9.UIcy0NVSM14KFhtDPQx9lURRArqCMeTuDTn3ckI09zxgoCrNKxOpUp0jG8HIA5rKk5jwaTnICIXrphcUO0xu4aIK5uJSblTKCH6qBnWkB2Dz5XldeAZLH2AfP6-ZnBUz6J03z-W2s-_RTVQprMY-0_wWlHKvn_EkUGpHKTDWvwjAg7luebokPj9sarUz2N20X7BPHbejEcbyiO5GeC1fYL1TZLm5m9E--vEfLtOkAQPbloz5lKhdW1WaMl7Rmq5hDsJ-vnfkYNbrfH77FO02cHgzxkHnOkH1-gk_a8DMsIAmBYt9bYDBqdMBqrO_JwEapPMZcZYyxxgoUibcp7P1Kg");
			Log.info("Header {}", header);
			MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
			body.add("contact-id",id);
			body.add("description","Front of Driver's License");
			body.add("file", partsEntity);
			body.add("label","Front Driver's License");
			body.add("public",true);
			HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, header);
			String url = "https://sandbox.primetrust.com/v2/uploaded-documents";
			response = restTemplate.postForEntity(url, entity, String.class);
			Log.info("response {}",response);
		} catch (Exception e) {
			
		}
		return response;
	}
	
	public ResponseEntity<String> getApiDetails(String id) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.MULTIPART_FORM_DATA));
		String url = "https://sandbox.primetrust.com/v2/uploaded-documents?contact.id=" + id;
		headers.setBearerAuth(
				"eyJhbGciOiJSUzI1NiJ9.eyJhdXRoX3NlY3JldCI6Ijc0N2Y2NTM2LTI2YWEtNDVlNi1iNjNjLTNkM2UxZTQ4ZjRkNyIsInVzZXJfZ3JvdXBzIjpbXSwibm93IjoxNjY5OTYzNzY5LCJleHAiOjE2NzUxMjMyMDB9.UIcy0NVSM14KFhtDPQx9lURRArqCMeTuDTn3ckI09zxgoCrNKxOpUp0jG8HIA5rKk5jwaTnICIXrphcUO0xu4aIK5uJSblTKCH6qBnWkB2Dz5XldeAZLH2AfP6-ZnBUz6J03z-W2s-_RTVQprMY-0_wWlHKvn_EkUGpHKTDWvwjAg7luebokPj9sarUz2N20X7BPHbejEcbyiO5GeC1fYL1TZLm5m9E--vEfLtOkAQPbloz5lKhdW1WaMl7Rmq5hDsJ-vnfkYNbrfH77FO02cHgzxkHnOkH1-gk_a8DMsIAmBYt9bYDBqdMBqrO_JwEapPMZcZYyxxgoUibcp7P1Kg");
		Log.info("header {}", headers);
		HttpEntity<String> entity = new HttpEntity<>(headers);

		ResponseEntity<String> res = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		Log.info("response {}", res);
		return res;
	}
	
	public ResponseEntity<String> getLatestListings() {
        String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest";
        
        HttpHeaders headers = new HttpHeaders();
//        headers.add("Accepts", "application/json");
        headers.set("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response;

	}
	
	public String getPrice(String assetName) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<String> response = restTemplate.exchange(
				"https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?symbol=" + "" + assetName,
				HttpMethod.GET, entity, String.class);
		
		JSONObject object = new JSONObject(response.getBody());
		JSONObject jsonRealData = object.getJSONObject("data");
		JSONObject json1 = jsonRealData.getJSONObject(assetName);
		JSONObject json2 = json1.getJSONObject("quote");
		JSONObject json3 = json2.getJSONObject("USD");
		PrimeTrustDto dto = new PrimeTrustDto();
		dto.setPrice(json3.get("price").toString());
		return dto.getPrice();
	}
	
	
	public String getDetailsOfCrypto(String id) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<String> response = restTemplate.exchange(
				"https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?id=" + "" + id,
				HttpMethod.GET, entity, String.class);
		Log.info("response {}",response);
		JSONObject object = new JSONObject(response.getBody());
		JSONObject jsonRealData = object.getJSONObject("data");
		JSONObject obj = jsonRealData.getJSONObject(id);
		JSONObject json2 = obj.getJSONObject("quote");
		JSONObject json3 = json2.getJSONObject("USD");
		PrimeTrustDto dto = new PrimeTrustDto();
		dto.setPrice(json3.get("price").toString());
		return dto.getPrice();
		
		}
	
	
	
	
	
//	  public String getPrice1(String assetName) {
//		    RestTemplate restTemplate = new RestTemplate();
//		    HttpHeaders headers = new HttpHeaders();
//		    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
//		    headers.add("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
//		    HttpEntity<String> entity = new HttpEntity<>(headers);
//		    String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?symbol="+assetName;
//		    ResponseEntity<String> response = restTemplate.exchange(String.format(url, assetName), HttpMethod.GET, entity, String.class);
//		    try {
//		      JSONObject json = new JSONObject(response.getBody());
//		      JSONArray data = json.getJSONArray("data");
//		      JSONObject crypto = data.getJSONObject(0);
//		      JSONObject quote = crypto.getJSONObject("quote").getJSONObject("USD");
//		      return quote.get("price").toString();
//		    } catch (JSONException e) {
//		      throw new RuntimeException(e);
//		    }
//		  }
	
	
		
	
	
	
	
	
	
	
	
//	public JSONObject getAssetInfo(@RequestParam String assetName) {
//		HttpHeaders headers = new HttpHeaders();
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		headers.add("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
//		HttpEntity entity = new HttpEntity(headers);
//		ResponseEntity<String> response = restTemplate.exchange(
//				"https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?symbol=" + "" + assetName,
//				HttpMethod.GET, entity, String.class);
//        JSONObject jsonResponse = new JSONObject(response);
//        JSONObject data = jsonResponse.getJSONObject("data");
//        for (int i = 0; i < data.length(); i++) {
//            JSONObject jsonObject = data.getJSONObject(i);
//            if (jsonObject.getString("symbol").equalsIgnoreCase(assetName)) {
//                return jsonObject;
//            }
//        }
//        return new JSONObject().put("error", "Asset not found");
//    }
//	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	public String getLatestListings(String assetName) {
//		
////		RestTemplateService rt = new RestTemplateService();
////		ResponseEntity<String> abc = rt.getLatestListings();
////		
//		
//		final String uri = "http://localhost:8080/latest";
//
//	    RestTemplate restTemplate = new RestTemplate();
//	    String result = restTemplate.getForObject(uri, String.class);
//
//	    
//	    JsonParser springParser = JsonParserFactory.getJsonParser();
//	    JsonParser springParser2 = JsonParserFactory.getJsonParser();
//
//	      Map < String, Object > map = springParser.parseMap(result);
//	      String mapArray[] = new String[map.size()];
//	      System.out.println("Items found: " + mapArray.length);
//	      int i = 0;
//	    
//	      System.out.println(map.keySet());
//	      System.out.println(map.get(map.keySet().toArray()[1]));
//	      
//	  
//	     // List<Long> offsets = new List(); .get(entry.getKey());
//	      
//	      //create json object
//	      
//	      JSONObject json = new JSONObject();
//	     
//	      for (Map.Entry < String, Object > entry: map.entrySet()) {
//	     //  Convert all Map keys to a List
//	  
//     
////    	  if(entry.getKey().equals("id")) 
////    	  {
////    		  
////    		  
//////    		  System.out.println("got the aid ");
//////    		  System.out.println(entry.getValue());
//////    	
//////    		  Map < String, Object > map = springParser.parseMap(entry.getValue());
//////    		  for (Map.Entry < String, Object > entry2: entry.getValue()) {
//////    	    	  if(entry.getKey()==assetName) 
//////    	    	  {
//////    	    		  
//////    	    	  }
////    	    	 
////    	        System.out.println(entry.getKey() + " = " + entry.getValue());
////
////  	      }
//    	  
//    	  		
//    	//  }
//	    	  json.put(entry.getKey() , entry.getValue());
//  //System.out.println(entry.getKey() + " = " + entry.getValue());
//        i++;
//    }
////	      JSONArray key = json.names ();
////	      for (int j = 0; j < key.length (); ++j) {
////	         String keys = key.getString(j); 
////	         String value = json.getString(keys);
////	         System.out.println(keys);
////	      }
////	      JSONObject jsonObj = new JSONObject(json.toString());
////	     
////	      JSONObject json = (JSONObject) JSONSerializer.toJSON(data);        
//	     // System.out.println(json.names().getString(0));
//	      
//	      
//	      
//	      // work from here 
//	      
//	      
//	return json.toString();
//		
//	}
//		
	
	
	
	
	
	
	
	
	
	//String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest";
		//String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?symbol="+assetName;
		//HttpHeaders headers = new HttpHeaders();
		//headers.add("Accepts", "application/json");
		
		
		//HttpEntity<String> entity = new HttpEntity<>(headers);
		//ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		//return response;
		//}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public ResponseEntity<String> getLatestQuotes() {
        String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest";
        HttpHeaders headers = new HttpHeaders();
        headers.add("Accepts", "application/json");
        headers.set("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response;

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

//    public ResponseEntity<String> getHistoricalInfo() {
//        //RestTemplate restTemplate = new RestTemplate();
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.add("Accepts", "application/json");
//        headers.add("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
//        HttpEntity<String> entity = new HttpEntity<>(headers);
//
//        String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/historical";
//        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
//        //ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
//
//        return response;
//    }

//

//    public ResponseEntity<String> getHistoricalInfo(LocalDate date) {
//        RestTemplate restTemplate = new RestTemplate();
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.add("Accepts", "application/json");
//        headers.add("X-CMC_PRO_API_KEY", "6a90f56f-e427-4c11-87c9-0e07c16558d7");
//        //HttpEntity<String> entity = new HttpEntity<>(headers);
//
//        String dateStr = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
//        String url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/historical";
//        
//        HttpEntity<String> entity = new HttpEntity<>(headers);
//        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
//        return response;
////        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
////                                                        .queryParam("date", dateStr);
////       return restTemplate.getForEntity(builder.toUriString(), String.class);
//////    }
//        //HttpEntity<String> entity = new HttpEntity<>(headers);
//        
//              //String url = "https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/historical";
//                //ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
//                //ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
//        
//                //return response;
//    }
}
	

