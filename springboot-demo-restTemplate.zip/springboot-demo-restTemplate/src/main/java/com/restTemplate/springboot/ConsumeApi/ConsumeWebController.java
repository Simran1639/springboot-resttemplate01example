package com.restTemplate.springboot.ConsumeApi;

import java.time.LocalDate;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.restTemplate.springboot.dto.PrimeTrustDto;
import com.restTemplate.springboot.service.RestTemplateService;

@RestController
public class ConsumeWebController {
	private static final Logger Log = LoggerFactory.getLogger(ConsumeWebController.class);
	
	@Autowired
	 private RestTemplateService restService;
	
	@PostMapping("/details")
	public ResponseEntity<String> postDetailsPT(@RequestBody PrimeTrustDto dto) {
		return restService.postWebService(dto);
	}
	
	@GetMapping("/details/{id}")
	public String consumeDetails(@PathVariable("id") String id) {
		return restService.getDetails(id);
	}
//	@GetMapping("/detail/{id}")
//	public Map<String, Object> consumeDetail(@PathVariable("id") String id) {
//		return restService.getDetail(id);
//	}
	
	@PostMapping("/uploadFiles")
	public ResponseEntity<String> addFiles(@RequestParam(value ="file") MultipartFile file, @RequestParam(value ="contact-id") String id){
		return restService.postDocument(file, id);
	}
	
	@GetMapping("/getDetails/{id}")
	public ResponseEntity<String> consumeRestTemplateDetail(@PathVariable("id") String id){
		return restService.getApiDetails(id);
	}
	
	
//	public ResponseEntity<String> getLatestPrice(HttpHeaders headers, int start, int limit, String convertId){
//		return restService.getLatestListings(headers, start, limit, convertId);
//	}
//	
	
	@GetMapping("/latest")
    public ResponseEntity<String> getLatestListings() {
        return restService.getLatestListings();
    }
	
	
	@GetMapping("/coin/{assetName}")
	public String getPrice(@PathVariable String assetName) {
		return restService.getPrice(assetName);
	}
	
	@GetMapping("/price/{id}")
	public String getsymbol(@PathVariable String id) {
		return restService.getDetailsOfCrypto(id);
	}
	
//	@GetMapping("/pricee/{assetName}")
//	  public String getPrice1(@PathVariable String assetName) {
//	    return restService.getPrice1(assetName);
//	  }
//	
	
	
	
//	@GetMapping("/cryptocurrency/{assetName}")
//    public JSONObject getCryptoCurrencyData(@PathVariable String assetName) {
//        return restService.getAssetInfo(assetName);
//    }
//	
	
	
	
	
	
	
	
	
	
	
	
//	@GetMapping("/crypto/historical")
//    public ResponseEntity<String> getHistoricalInfo() {
//        return restService.getHistoricalInfo();
//    }
	
//	@GetMapping("/historical")
//    public ResponseEntity<String> getHistoricalData(@RequestParam("date") String date) {
//        LocalDate localDate = LocalDate.parse(date);
//        return restService.getHistoricalInfo(localDate);
//    }
//	
//	@GetMapping("/getQuotes")
//    public ResponseEntity<String> getLatestQuotes() {
//        return restService.getLatestQuotes();
//    }
//	
}
	

