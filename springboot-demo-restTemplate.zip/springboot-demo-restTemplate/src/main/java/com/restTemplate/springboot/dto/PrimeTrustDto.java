package com.restTemplate.springboot.dto;

import java.util.Date;

import lombok.Data;

@Data
public class PrimeTrustDto {
	
	private String name; 
	private String authorizedSignature;
	private String ownerName;
	private String email;
	private String dateOfBirth;
	private String taxIdNumber;
	private String taxCuntry;
	private String ipAddress;
	private String geoLocation;
	private String country;
	private String number;
	private boolean sms;
	private String streetOne;
	private String streetTwo;
	private String postalCode;
	private String city;
	private String region;
	private String paCountry;
	private String url;
	private String price;
	private String volume_24h;
	

}
